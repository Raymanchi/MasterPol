﻿using System.Linq;
using System.Windows;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Istoriya.xaml
    /// </summary>
    public partial class Istoriya : Window
    {
        ramadEntities db = new ramadEntities();
        public Istoriya()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //Запись в переменные таблицы из базы данных
            var partnerProducts = db.partnerProducts.ToList();
            var partners = db.partners.ToList();
            var products = db.products.ToList();

            //Соединение таблиц через join
            var partners_products = from pa in partnerProducts join pr in products on pa.id_products equals pr.id select new { idPartner = pa.id_partner, count = pa.count, date = pa.date, nameProduct = pr.name };
            var partnerProd = from pa in partners_products join pr in partners on pa.idPartner equals pr.id select new { partner = pr.name, count = pa.count, date = pa.date, product = pa.nameProduct };

            istoriyaList.ItemsSource = partnerProd.ToList();
        }

        //Кнопка возвращения на начальное окно
        private void back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.Show();
            this.Close();
        }
    }
}
