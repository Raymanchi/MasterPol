﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для RaschetMaterial.xaml
    /// </summary>
    public partial class RaschetMaterial : Window
    {
        ramadEntities db = new ramadEntities();
        public RaschetMaterial()
        {
            InitializeComponent();
        }

        //метод для расчёта нужного количества материала
        private int metod(int product, int count, int type, double first, double second)
        {
            var typeProduct = db.productType.FirstOrDefault(x => x.id == product);
            var material = db.material.FirstOrDefault(x => x.id == type);
            var materialType = db.materialType.FirstOrDefault(x => x.id == material.id_typeMaterial);
            double materialForOne = first * second * (double)typeProduct.coefficient;
            double materialForAll = materialForOne * count;
            double brak = materialForAll * (double)materialType.percentDefective;
            return Convert.ToInt32(Math.Floor(materialForAll + brak));
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }

        private void go_Click(object sender, RoutedEventArgs e)
        {
            var selectedProduct = db.products.FirstOrDefault(x => x.id == (int)productBox.SelectedValue);

            var materialForManufacturer = db.materialForManufacturer.FirstOrDefault(x => x.id_products == selectedProduct.id);
            var materialList = db.material.FirstOrDefault(x => x.id == materialForManufacturer.id_material);
            var materialType = db.materialType.FirstOrDefault(x => x.id == materialList.id_typeMaterial);

            MessageBox.Show("Для создания " + count.Text + " " + selectedProduct.name + " нужно " + metod((int)productBox.SelectedValue, Convert.ToInt32(count.Text), (int)materialType.id, Convert.ToDouble(first.Text), Convert.ToDouble(second.Text)) + " материала " + materialList.name);
        }

        // Инициализация выпадающего списка
        private void productBox_Loaded(object sender, RoutedEventArgs e)
        {
            productBox.ItemsSource = db.products.ToList();
            productBox.DisplayMemberPath = "name";
            productBox.SelectedValuePath = "id";
        }
    }
}
