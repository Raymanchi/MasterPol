﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Edit.xaml
    /// </summary>
    public partial class Edit : Window
    {
        ramadEntities db = new ramadEntities();
        public Edit()
        {
            InitializeComponent();
        }
        
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Инициализация выпадающего списка
            combobox.ItemsSource = db.partnerType.ToList();
            combobox.DisplayMemberPath = "name";
            combobox.SelectedValuePath = "id";

            partnerid partnerid = new partnerid();
            var partner = db.partners.FirstOrDefault(x => x.id == partnerid.id);
            var partnertype = db.partnerType.FirstOrDefault(x => x.id == partner.id_partnerType);
            var adress = db.adress.FirstOrDefault(x => x.id == partner.id_adress);
            var contact = db.partnerContact.FirstOrDefault(x => x.id == partner.id_contact);

            partner_name.Text = partner.name;
            combobox.Text = partnertype.name;
            rate.Text = partner.rating.ToString();
            inn.Text = partner.inn;
            postal_code.Text = adress.postalCode.ToString();
            area.Text = adress.area;
            city.Text = adress.city;
            street.Text = adress.street;
            home.Text = adress.houseNumber;
            director_familiya.Text = contact.lastname;
            director_name.Text = contact.name;
            director_otchestvo.Text = contact.fathername;
            phone.Text = contact.telephone;
            email.Text = contact.email;
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.Show();
            this.Close();
        }

        private void save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var partner = db.partners.FirstOrDefault(x => x.id == partnerid.id);
                var type = db.partnerType.FirstOrDefault(x => x.id == partner.id_partnerType);
                var adress = db.adress.FirstOrDefault(x => x.id == partner.id_adress);
                var contact = db.partnerContact.FirstOrDefault(x => x.id == partner.id_contact);

                if (partner_name.Text != "" && combobox.Text != "" && rate.Text != "" && postal_code.Text != "" && area.Text != "" && city.Text != "" && street.Text != "" && home.Text != "" && phone.Text != "" && email.Text != "" && director_name.Text != "" && director_familiya.Text != "" && director_otchestvo.Text != "" && inn.Text != "")
                {
                    contact.name = director_name.Text;
                    contact.lastname = director_familiya.Text;
                    contact.fathername = director_otchestvo.Text;
                    adress.postalCode = Convert.ToInt32(postal_code.Text);
                    adress.area = area.Text;
                    adress.city = city.Text;
                    adress.street = street.Text;
                    adress.houseNumber = home.Text;
                    contact.telephone = phone.Text;
                    contact.email = email.Text;
                    partner.rating = Convert.ToInt32(rate.Text);
                    partner.id_partnerType = Convert.ToInt32(combobox.SelectedValue);
                    partner.id_adress = adress.id;
                    partner.id_contact = contact.id;
                    partner.name = partner_name.Text;
                    db.SaveChanges();
                    MessageBox.Show("Партнёр " + partner.name + " изменен");
                }
                else
                {
                    MessageBox.Show("Не все поля заполнены");
                }
            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.Message);
            }
           
        }
    }
}
