﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public class PartnerDiscount
    {
        public int id_partner {  get; set; }
        public int total_count { get; set; }
        public double discount { get; set; }
    }
}
