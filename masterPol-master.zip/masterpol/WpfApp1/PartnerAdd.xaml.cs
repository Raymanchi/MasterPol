﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для PartnerAdd.xaml
    /// </summary>
    public partial class PartnerAdd : Window
    {
        ramadEntities db = new ramadEntities();
        public PartnerAdd()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Инициализация выпадающего списка
            combobox.ItemsSource = db.partnerType.ToList();
            combobox.DisplayMemberPath = "name";
            combobox.SelectedValuePath = "id";
        }

        private void save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (partner_name.Text != "" && combobox.Text != "" && rate.Text != "" && postal_code.Text != "" && area.Text != "" && city.Text != "" && street.Text != "" && home.Text != "" && phone.Text != "" && email.Text != "" && director_name.Text != "" && director_familiya.Text != "" && director_otchestvo.Text != "" && inn.Text != "")
                {
                    if (email.Text.Contains("@") && email.Text.Contains(".ru") || email.Text.Contains(".com"))
                    {
                        partnerContact contacts = new partnerContact
                        {
                            email = email.Text,
                            telephone = phone.Text,
                            fathername = director_familiya.Text,
                            name = director_name.Text,
                            lastname = director_otchestvo.Text
                        };
                        db.partnerContact.Add(contacts);
                        adress adress = new adress
                        {
                            postalCode = Convert.ToInt32(postal_code.Text),
                            area = area.Text,
                            city = city.Text,
                            street = street.Text,
                            houseNumber = home.Text,
                        };
                        db.adress.Add(adress);
                        partners user = new partners
                        {
                            name = partner_name.Text,
                            inn = inn.Text,
                            rating = Convert.ToInt32(rate.Text),
                            id_adress = adress.id,
                            id_contact = contacts.id,
                            id_partnerType = (int)combobox.SelectedValue
                        };
                        db.partners.Add(user);
                        partnerProducts partnerProducts = new partnerProducts()
                        {
                            id_partner = user.id,
                            count = 0
                        };
                        db.partnerProducts.Add(partnerProducts);


                        db.SaveChanges();
                        MessageBox.Show("партнер добавлен");
                    }
                    else
                    {
                        MessageBox.Show(" Проверьте корректность ввода данных");
                    }
                }
                else
                {
                    MessageBox.Show("Пожалуйста Заполните все поля");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.Show();
            this.Close();
        }

        // Проверка ввода только для чисел
        private void NumericInput_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if ((e.Key < Key.D0 || e.Key > Key.D9) && e.Key != Key.Back)
            {
                e.Handled = true;
            }
        }

        // Проверка ввода только для букв
        private void AlphabetInput_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if ((e.Key < Key.A || e.Key > Key.Z) && e.Key != Key.Back && e.Key != Key.Space)
            {
                e.Handled = true;
            }
        }

        // Обработчики событий для конкретных полей
        private void rate_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            // Разрешить только цифры и клавишу Backspace
            if ((e.Key < Key.D0 || e.Key > Key.D9) && e.Key != Key.Back && e.Key != Key.OemMinus)
            {
                e.Handled = true;
            }
        }

        // Применение общей проверки для других полей с вводом только цифр
        private void inn_PreviewKeyDown(object sender, KeyEventArgs e) => NumericInput_PreviewKeyDown(sender, e);
        private void phone_PreviewKeyDown(object sender, KeyEventArgs e) => NumericInput_PreviewKeyDown(sender, e);

        // Применение общей проверки для полей с вводом только букв
        private void partner_type_PreviewKeyDown(object sender, KeyEventArgs e) => AlphabetInput_PreviewKeyDown(sender, e);
        private void partner_name_PreviewKeyDown(object sender, KeyEventArgs e) => AlphabetInput_PreviewKeyDown(sender, e);
        private void director_PreviewKeyDown(object sender, KeyEventArgs e) => AlphabetInput_PreviewKeyDown(sender, e);     
    }
}
